##########################################################################################
# author: Pintu Patra
# contact: pintu.patra@bioquant.uni-heidelberg.de
# date: 2021-25-10

To run the agent-based simulation code in single-step run "code-run.c" file. Use the following set of commands.
1) gcc code-run.c
2) ./a.out

The "code-run.c" file compiles all the required files, runs the simulation (with 5001 time steps here), and prepares the simulation movie.
To change the model parameters, modify "inputpar.py" file.





